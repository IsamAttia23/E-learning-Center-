﻿using ELearnigCenter.Shared.Entities;

namespace ELearnigCenter.Models
{
    public class Enrollment : TEntity<Guid>
    {
        public User User { get; set; }
        public Guid UserId { get; set; }
        public Course Course { get; set; }
        public Guid CourseId { get; set; }
        public ICollection<StudentsEnrollmet> Students { get; set; }
    }
}
