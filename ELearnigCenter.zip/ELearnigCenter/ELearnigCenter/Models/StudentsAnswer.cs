﻿using ELearnigCenter.Shared.Entities;

namespace ELearnigCenter.Models
{
    public class StudentsAnswer : TEntity<Guid>
    {
        public User User { get; set; }
        public Guid Student { get; set; }
        public Answer Answer { get; set; }
        public Guid AnswerId { get; set; }
    }
}
