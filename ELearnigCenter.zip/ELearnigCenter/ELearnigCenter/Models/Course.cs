﻿using ELearnigCenter.Shared.Entities;

namespace ELearnigCenter.Models
{
    public class Course : TEntity<Guid>
    {
        public string Description { get; set; }
        public User User { get; set; }
        public Guid TeacherId { get; set; }
        public ICollection<Quize> Quizes { get; set; }
        public Certificate Certificate { get; set; }
    }
}
