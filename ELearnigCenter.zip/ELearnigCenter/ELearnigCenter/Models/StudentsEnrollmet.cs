﻿using ELearnigCenter.Shared.Entities;

namespace ELearnigCenter.Models
{
    public class StudentsEnrollmet : TEntity<Guid>
    {
        public User User { get; set; }
        public Guid StudentId { get; set; }
        public Enrollment Enrollment { get; set; }
        public Guid EnrollmentId { get; set; }
    }
}
