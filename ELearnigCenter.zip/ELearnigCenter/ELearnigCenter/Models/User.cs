﻿using ELearnigCenter.Shared.Entities;

namespace ELearnigCenter.Models
{
    public class User : TEntity<Guid>
    {
        public string Email { get; set; }
        public string Password { get; set; }
        public enum Role {Student , Teatcher , Admin }
        public ICollection<Course> Courses { get; set; }
        public ICollection<StudentsEnrollmet> Enrollmets { get; set; }
        public ICollection<StudentsAnswer> Answers { get; set; }
        public Certificate Certificate { get; set; }
        public Guid CertificateId { get; set; }
     
    }
}
