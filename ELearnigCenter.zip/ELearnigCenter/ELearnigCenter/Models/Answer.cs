﻿using ELearnigCenter.Shared.Entities;

namespace ELearnigCenter.Models
{
    public class Answer : TEntity<Guid>
    {
        public Question Question { get; set; }
        public Guid QuestionId { get; set; }
        public ICollection<StudentsAnswer> Students { get; set; }
        public Boolean IsCorrect { get; set; }
    }
}
