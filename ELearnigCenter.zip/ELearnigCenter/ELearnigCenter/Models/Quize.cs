﻿using ELearnigCenter.Shared.Entities;

namespace ELearnigCenter.Models
{
    public class Quize : TEntity<Guid>
    {
        public Course Course { get; set; }
        public Guid CourseId { get; set; }
        public ICollection<Question> Questions { get; set; }
    }
}
