﻿using ELearnigCenter.Shared.Entities;

namespace ELearnigCenter.Models
{
    public class Question : TEntity<Guid>
    {
        public Quize Quize { get; set; }
        public Guid QuizeId { get; set; }
    }
}
