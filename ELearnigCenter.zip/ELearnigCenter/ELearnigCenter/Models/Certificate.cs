﻿using ELearnigCenter.Shared.Entities;

namespace ELearnigCenter.Models
{
    public class Certificate : TEntity<Guid>
    {
        public Course Course { get; set; }
        public Guid CourseId { get; set; }
        public User User { get; set; }
        public Guid UserId { get; set; }
    }
}
