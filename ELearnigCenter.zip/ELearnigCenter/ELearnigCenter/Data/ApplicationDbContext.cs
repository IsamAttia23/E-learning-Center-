﻿using ELearnigCenter.Models;
using Microsoft.EntityFrameworkCore;

namespace ELearnigCenter.Data
{
    public class ApplicationDbContext : DbContext
    {
        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options) : base(options)
        {

        }

        public DbSet<Answer> Answers { get; set; }
        public DbSet<Certificate> Certificates { get; set; }
        public DbSet<Course> Courses { get; set; }
        public DbSet<Enrollment> Enrollments { get; set; }
        public DbSet<Question> Questions { get; set; }
        public DbSet<Quize> Quizes { get; set; }
        public DbSet<User> Users { get; set; }
    }
}
