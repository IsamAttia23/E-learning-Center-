﻿namespace ELearnigCenter.Shared.Entities
{
    public interface TId<Id> where Id : struct
    {
        public Id ID { get; set; }
    }
}
