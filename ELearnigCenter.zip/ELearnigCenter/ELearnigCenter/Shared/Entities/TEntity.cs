﻿namespace ELearnigCenter.Shared.Entities
{
    public class TEntity<Id> : TId<Id>
        where Id : struct
    {
        public Id ID { get; set; }
        public string Name { get; set; }
        public DateTimeOffset CreatedOn { get; set; }
        public DateTimeOffset? UpdatedOn { get;set; }
        public DateTimeOffset? DeletedOn { get; set; }
    }
}
